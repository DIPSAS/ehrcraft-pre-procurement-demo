
We used Better Archetype Designer (https://ehrscape.marand.si/designerv2) when designing and exporting these files. The two *-exported-as-fileset directories contain files exported using "Export fileset". The 354 kb pre-procurement-demo.opt template in the "Templates-exported-as-fileset" directory is thus smaller than than the "normal" 407 kb pre-procurement-demo.opt here in the root directory where this readme.txt file resides. 

Most form building tools/system we know of will prefer using only the 407kb pre-procurement-demo.opt file found here in the same directory as the readme.txt file and for demo use this in combination with patient data in the file Patient-data-examples-in-pre-procurement-demo.xlsx (Thus ignoriing all other files.)

Please note that Patient-data-examples-in-pre-procurement-demo.xlsx has a filter based on "Yes" in column G. Column K-N contains patient data examples for the demo. 

The pre-procurement-demo-empty.xlsx is the file that the Patient-data-examples-in-pre-procurement-demo.xlsx was based on before adding formatting, help and sample data